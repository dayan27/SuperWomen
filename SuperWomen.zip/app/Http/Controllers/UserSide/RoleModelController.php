<?php

namespace App\Http\Controllers\UserSide;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RoleModelController extends Controller
{
    public function getRoleModels(){

    }

    public function addComment(){

    }

    public function addReply(){

    }
}
