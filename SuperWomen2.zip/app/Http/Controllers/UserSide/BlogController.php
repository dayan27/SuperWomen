<?php

namespace App\Http\Controllers\UserSide;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BlogController extends Controller
{
    public function getBlogs(){

    }

    public function addComment(){

    }

    public function addReply(){

    }
}
